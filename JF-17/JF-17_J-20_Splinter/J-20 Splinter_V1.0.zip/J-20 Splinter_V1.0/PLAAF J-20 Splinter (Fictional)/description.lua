--- livery by Flightless Ivan
----------------------------------------LIVERY---------------------------------------------------------------
livery = {
	----------------------------------AIRCRAFT BODY----------------------------------
	--01
    {"JF-17_main01"			, 0  , 		"JF-17_01_a"		, false},
	{"JF-17_main01"			, 13  ,		"JF-17_01_mg"		, false},
		--Decal
		{"JF-17_main01_BN52"	, 3  , 		"empty"				, true },
    	{"JF-17_main01_BN31"	, 3  , 		"empty"				, true },
    	{"JF-17_main01_BN32"	, 3  , 		"empty"				, true },
		--Decal BackGround
    	{"JF-17_main01_BN52"	, 0  , 		"JF-17_01_a"		, false},
		{"JF-17_main01_BN52"	, 13 ,		"JF-17_01_mg"		, false},
    	{"JF-17_main01_BN31"	, 0  , 		"JF-17_01_a"		, false},
		{"JF-17_main01_BN31"	, 13 ,		"JF-17_01_mg"		, false},
    	{"JF-17_main01_BN32"	, 0  , 		"JF-17_01_a"		, false},
		{"JF-17_main01_BN32"	, 13 ,		"JF-17_01_mg"		, false},


	--02
    {"JF-17_main02"			, 0  , 		"JF-17_02_a"		, false},
	{"JF-17_main02"			, 13 ,		"JF-17_02_mg"		, false},

	--03
    {"JF-17_main03"			, 0  ,		"JF-17_03_a"		, false},
	{"JF-17_main03"			, 13 ,		"JF-17_03_mg"		, false},

	--04
    {"JF-17_main04"			, 0  , 		"JF-17_04_a"		, false},
	{"JF-17_main04"			, 13 ,		"JF-17_04_mg"		, false},

	--05
    {"JF-17_main05"			, 0  , 		"JF-17_05_a"		, false},
	{"JF-17_main05"			, 13 ,		"JF-17_05_mg"		, false},

	--06
    {"JF-17_main06"			, 0  , 		"JF-17_06_a"		, false},
	{"JF-17_main06"			, 13 ,		"JF-17_06_mg"		, false},

	--07
    {"JF-17_main07"			, 0  , 		"JF-17_07_a"		, false},
	{"JF-17_main07"			, 13 ,		"JF-17_07_mg"		, false},

	--08
    {"JF-17_main08"			, 0  , 		"JF-17_08_a"		, false},
	{"JF-17_main08"			, 13 ,		"JF-17_08_mg"		, false},
		--Decal
		{"JF-17_main08_decol"	, 3  , 		"empty"				, true },
		{"JF-17_main08_BN52"	, 3  , 		"empty"				, true },
		{"JF-17_main08_BN31"	, 3  , 		"empty"				, true },
		{"JF-17_main08_BN32"	, 3  , 		"empty"				, true },
		--Decal BackGround
		{"JF-17_main08_decol"	, 0  , 		"JF-17_08_a"		, false},
		{"JF-17_main08_decol"	, 13 ,		"JF-17_08_mg"		, false},
		{"JF-17_main08_BN52"	, 0  , 		"JF-17_08_a"		, false},
		{"JF-17_main08_BN52"	, 13 ,		"JF-17_08_mg"		, false},
		{"JF-17_main08_BN31"	, 0  , 		"JF-17_08_a"		, false},
		{"JF-17_main08_BN31"	, 13 ,		"JF-17_08_mg"		, false},
		{"JF-17_main08_BN32"	, 0  , 		"JF-17_08_a"		, false},
		{"JF-17_main08_BN32"	, 13 ,		"JF-17_08_mg"		, false},


	--09
    {"JF-17_main09"			, 0  , 		"JF-17_09_a"		, false},
	{"JF-17_main09"			, 13 ,		"JF-17_09_mg"		, false},

	--Engine
	{"JF-17_metal"			, 0  , 		"JF-17_engine_a"	, false},
	{"JF-17_metal"			, 13 ,		"JF-17_engine_mg"	, false},
	---------------------------------LOAD---------------------------------------
	--Fuel Tank (Not improved yet)
	--{"Tank_800"			, 0  , 		"tank800_a"			, false};
	--{"Tank_800"			, 13 , 		"tank800_mg"		, false};
	--{"Tank_1100"			, 0  , 		"tank1100_a"		, false};
	--{"Tank_1100"			, 13 , 		"tank1100_mg"		, false};

} --end of livery{}
----------------------------------------END LIVERY---------------------------------------------------------------


---Livery name in game
name    = "PLAAF J-20 Splinter (Fictional)"
name_cn = "PLAAF 歼-20 割裂迷彩 (虚构)"

--------------------------------------NOTE-----------------------------------------
---FILE NAME STRUCTURE
	-- a = diffuse map
	-- mg = roughness metallic map
	-- n = normal map


---RENDER TYPE/CODE
	--DIFFUSE = 0
	--NORMAL_MAP = 1
	--SPECULAR = 2
	--DECAL = 3
	--DIRT = 4
	--DAMAGE = 5
	--PUDDLES = 6
	--SNOW = 7
	--SELF_ILLUMINATION = 8
	--AMBIENT_OCCLUSION = 9
	--ROUGHNESS_METALLIC = 13
	--OPACITY = 14