livery = {
    {"底盘", 0, "ztz96b_baseplate", false};
	{"底盘", ROUGHNESS_METALLIC, "ztz96b_baseplate_RoughMet", false};
    {"炮塔", 0, "ztz96b_turret", false};
	{"炮塔", ROUGHNESS_METALLIC, "ztz96b_turret_RoughMet", false};
    {"履带", 0, "ztz96b_track", false};
	{"履带", ROUGHNESS_METALLIC, "ztz96b_track_RoughMet", false};
}
name = "Tank biathlon - 601 (Desert)"
name_cn = "坦克两项 - 601 (沙漠迷彩)"
name_ru = "Танковый биатлон - 601 (пустыня)"