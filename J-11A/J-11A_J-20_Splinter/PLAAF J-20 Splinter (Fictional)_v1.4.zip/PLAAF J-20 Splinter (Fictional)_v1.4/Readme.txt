\\\     This is a Readme file and can be deleted directly   \\\

To use this mod: 
        -   Unzip and paste the 'Liveries' folder into:         DCSWorld\CoreMods\aircraft\ChinaAssetPack  ; (It may break the online game Integrity Check)
        -   Or paste into this path:                            C:\User\'Your user name'\SavedGame\DCS     ;

All materials/picture are taken from the Internet;





\\\     此文件可直接删除不影响使用    \\\

食用方法:
        -   将 'Liveries' 文件夹解压并放入:         DCSWorld\CoreMods\aircraft\ChinaAssetPack  ; (可能会无法通过联机完整性检查)
        -   或放入以下路径:                         C:\用户\'你的用户名'\保存的游戏\DCS          ;


所有素材均来自互联网;


(真的会有人读readme吗(