livery = {

	--Misc
    {"pilot_Ka50_body"		, 0	,	"pilot_J11a"			, false};
    {"pilot_SU_body"		, 0	,	"pilot_cnk"			    , false};
    {"pilot_J11a_helmet"	, 0	,	"pilot_J11a_helmet"	    , false};
    {"pilot_J11a_patch"		, 0	,	"pilot_J11a_patch"	    , false};
    {"j11a_glass"           , 0 ,   "J11a_glass"            , false};
    {"j11a_glass_compos"    , 0 ,   "J11a_glass"            , false};
    {"j11a_glass"           , 3 ,   "empty"                 , true};
    {"j11a_glass_compos"    , 3 ,   "empty"                 , true};

	--Emblems+Numbers
    {"j11a_tex01"			, 3	,	"J11a_decol"			, false};
    {"j11a_tex03_compos"	, 3	,	"J11a_decol"			, false};
    {"j11a_tex04"			, 3	,	"J11a_decol"			, false};
    {"j11a_tex05"			, 3	,	"J11a_decol"			, false};
    {"j11a_tex06"			, 3	,	"J11a_decol"			, false};
    {"j11a_tex06_BN52"		, 3	,	"J11a_numbers_Y"		, false};
    {"j11a_tex06_BN31"		, 3	,	"J11a_numbers_Y"		, false};
    {"j11a_tex06_BN32"		, 3	,	"J11a_numbers_Y"		, false};
	
	--Numbers Backgound
    {"j11a_tex06_BN52"		, 0	,	"J11a_tex06"			, false};
    {"j11a_tex06_BN31"		, 0	,	"J11a_tex06"			, false};
    {"j11a_tex06_BN32"		, 0	,	"J11a_tex06"			, false};

	--Skin Textures
    {"j11a_tex01"			, 0	,	"J11a_tex01"			, false};
    {"j11a_tex02_compos"	, 0	,	"J11a_tex02"			, false};
    {"j11a_tex02"			, 0	,	"J11a_tex02"			, false};
    {"j11a_tex03"			, 0	,	"J11a_tex03"			, false};
    {"j11a_tex03_compos"	, 0	,	"J11a_tex03"			, false};
    {"j11a_tex04"			, 0	,	"J11a_tex04"			, false};
    {"j11a_tex05"			, 0	,	"J11a_tex05"			, false};
    {"j11a_tex06"			, 0	,	"J11a_tex06"			, false};
    {"j11a_tex07"			, 0	,	"J11a_tex07"			, false};
	{"j11a_RKL609L"			, 0 ,	"J11a_RKL609L"		    , false};
	{"j11a_RKL609R"			, 0 ,	"J11a_RKL609R"		    , false};
    {"j11a_AKU170"			, 0 ,	"J11a_AKU170"		    , false};
    {"j11a_detail"          , 0 ,   "J11a_detail"           , false};
    {"j11a_detail_compos"   , 0 ,   "J11a_detail"           , false};

    --SPC (RoughnessMetallic/"Roughmet")
    {"j11a_tex01"			, 2	,	"J11a_tex01_SPC"		, false};
    {"j11a_tex01_BN52"		, 2	,	"J11a_tex01_SPC"		, false};
    {"j11a_tex01_BN31"		, 2	,	"J11a_tex01_SPC"		, false};
    {"j11a_tex01_BN32"		, 2	,	"J11a_tex01_SPC"		, false};
    {"j11a_tex02"			, 2	,	"J11a_tex02_SPC"		, false};
    {"j11a_tex02_compos"	, 2	,	"J11a_tex02_SPC"		, false};
    {"j11a_tex03"			, 2	,	"J11a_tex03_SPC"		, false};
    {"j11a_tex03_compos"	, 2	,	"J11a_tex03_SPC"		, false};
    {"j11a_tex04"			, 2	,	"J11a_tex04_SPC"		, false};
    {"j11a_tex05"			, 2	,	"J11a_tex05_SPC"		, false};
    {"j11a_tex06"			, 2	,	"J11a_tex06_SPC"		, false};
    {"j11a_tex06_BN52"		, 2	,	"J11a_tex06_SPC"		, false};
    {"j11a_tex06_BN31"		, 2	,	"J11a_tex06_SPC"		, false};
    {"j11a_tex06_BN32"		, 2	,	"J11a_tex06_SPC"		, false};
    {"j11a_tex07"			, 2	,	"J11a_tex07_SPC"		, false};
    {"j11a_RKL609L"			, 2 ,	"J11a_RKL609L_SPC"		, false};
	{"j11a_RKL609R"			, 2 ,	"J11a_RKL609R_SPC"		, false};
    {"j11a_AKU170"			, 2 ,	"J11a_AKU170_SPC"		, false};
    {"j11a_detail"          , 2 ,   "J11a_detail_SPC"       , false};
    {"j11a_detail_compos"   , 2 ,   "J11a_detail_SPC"       , false};
    {"j11a_glass"           , 2 ,   "J11a_glass_SPC"        , false};
    {"j11a_glass_compos"    , 2 ,   "J11a_glass_SPC"        , false};


    --Cockpit
    {"su27_tex01"			, 0	,	"J11a_tex01"		    , false};
    {"su27_tex01"			, 3 ,	"J11a_decol"		    , false};
}

	--Displaynames
    name     =    "PLAAF OPFOR 'J-20 Scheme' (Fictional+RoughMet)"
    name_cn  =    "PLAAF 割裂迷彩 '歼-20' (虚构+磨砂)"

	--Livery by fightless Ivan
