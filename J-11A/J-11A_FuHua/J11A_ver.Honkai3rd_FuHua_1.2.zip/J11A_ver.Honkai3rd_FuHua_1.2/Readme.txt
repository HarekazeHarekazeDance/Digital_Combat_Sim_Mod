\\\     This is a Readme file and can be deleted directly   \\\

To use this mod: 
    
        -   Unzip and paste the 'CoreMods' folder into your DCS root folder;


All materials/picture are taken from the Internet;





\\\     此文件可直接删除不影响使用    \\\

食用方法:

        -   将 'CoreMods' 文件夹解压并放入 DCS 根目录;


所有素材均来自互联网;


(真的会有人读readme吗(