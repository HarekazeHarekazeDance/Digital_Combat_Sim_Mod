livery = {

	--Misc
    {"pilot_Ka50_body"		, 0	,	"pilot_J11a_FuHua"			, false};
    {"pilot_SU_body"		, 0	,	"pilot_cnk_FuHua"			, false};
    {"pilot_J11a_helmet"	, 0	,	"pilot_J11a_helmet_FuHua"	, false};
    {"pilot_J11a_patch"		, 0	,	"pilot_J11a_patch_FuHua"	, false};
    {"j11a_glass"           , 0 ,   "J11a_glass_FuHua"          , false};
    {"j11a_glass_compos"    , 0 ,   "J11a_glass_FuHua"          , false};
    {"j11a_glass"           , 3 ,   "empty"                     , true};
    {"j11a_glass_compos"    , 3 ,   "empty"                     , true};

	--Emblems+Numbers
    {"j11a_tex01"			, 3	,	"J11a_decol_FuHua"			, false};
    {"j11a_tex03_compos"	, 3	,	"J11a_decol_FuHua"			, false};
    {"j11a_tex04"			, 3	,	"J11a_decol_FuHua"			, false};
    {"j11a_tex05"			, 3	,	"J11a_decol_FuHua"			, false};
    {"j11a_tex06"			, 3	,	"J11a_decol_FuHua"			, false};
    {"j11a_tex06_BN52"		, 3	,	"J11a_numbers_Y_FuHua"		, false};
    {"j11a_tex06_BN31"		, 3	,	"J11a_numbers_Y_FuHua"		, false};
    {"j11a_tex06_BN32"		, 3	,	"J11a_numbers_Y_FuHua"		, false};
	
	--Numbers Backgound
    {"j11a_tex06_BN52"		, 0	,	"J11a_tex06_FuHua"			, false};
    {"j11a_tex06_BN31"		, 0	,	"J11a_tex06_FuHua"			, false};
    {"j11a_tex06_BN32"		, 0	,	"J11a_tex06_FuHua"			, false};

	--Skin Textures
    {"j11a_tex01"			, 0	,	"J11a_tex01_FuHua"			, false};
    {"j11a_tex02_compos"	, 0	,	"J11a_tex02_FuHua"			, false};
    {"j11a_tex02"			, 0	,	"J11a_tex02_FuHua"			, false};
    {"j11a_tex03"			, 0	,	"J11a_tex03_FuHua"			, false};
    {"j11a_tex03_compos"	, 0	,	"J11a_tex03_FuHua"			, false};
    {"j11a_tex04"			, 0	,	"J11a_tex04_FuHua"			, false};
    {"j11a_tex05"			, 0	,	"J11a_tex05_FuHua"			, false};
    {"j11a_tex06"			, 0	,	"J11a_tex06_FuHua"			, false};
    {"j11a_tex07"			, 0	,	"J11a_tex07_FuHua"			, false};
	{"j11a_RKL609L"			, 0 ,	"J11a_RKL609L_FuHua"		, false};
	{"j11a_RKL609R"			, 0 ,	"J11a_RKL609R_FuHua"		, false};
    {"j11a_AKU170"			, 0 ,	"J11a_AKU170_FuHua"		    , false};
    {"j11a_detail"          , 0 ,   "J11a_detail_FuHua"         , false};
    {"j11a_detail_compos"   , 0 ,   "J11a_detail_FuHua"         , false};

    --SPC (RoughnessMetallic/"Roughmet")
    {"j11a_tex01"			, 2	,	"J11a_tex01_FuHua_SPC"		, false};
    {"j11a_tex01_BN52"		, 2	,	"J11a_tex01_FuHua_SPC"		, false};
    {"j11a_tex01_BN31"		, 2	,	"J11a_tex01_FuHua_SPC"		, false};
    {"j11a_tex01_BN32"		, 2	,	"J11a_tex01_FuHua_SPC"		, false};
    {"j11a_tex02"			, 2	,	"J11a_tex02_FuHua_SPC"		, false};
    {"j11a_tex02_compos"	, 2	,	"J11a_tex02_FuHua_SPC"		, false};
    {"j11a_tex03"			, 2	,	"J11a_tex03_FuHua_SPC"		, false};
    {"j11a_tex03_compos"	, 2	,	"J11a_tex03_FuHua_SPC"		, false};
    {"j11a_tex04"			, 2	,	"J11a_tex04_FuHua_SPC"		, false};
    {"j11a_tex05"			, 2	,	"J11a_tex05_FuHua_SPC"		, false};
    {"j11a_tex06"			, 2	,	"J11a_tex06_FuHua_SPC"		, false};
    {"j11a_tex06_BN52"		, 2	,	"J11a_tex06_FuHua_SPC"		, false};
    {"j11a_tex06_BN31"		, 2	,	"J11a_tex06_FuHua_SPC"		, false};
    {"j11a_tex06_BN32"		, 2	,	"J11a_tex06_FuHua_SPC"		, false};
    {"j11a_tex07"			, 2	,	"J11a_tex07_FuHua_SPC"		, false};
    {"j11a_detail"          , 2 ,   "J11a_detail_FuHua_SPC"     , false};
    {"j11a_detail_compos"   , 2 ,   "J11a_detail_FuHua_SPC"     , false};
    {"j11a_glass"           , 2 ,   "J11a_glass_FuHua_SPC"      , false};
    {"j11a_glass_compos"    , 2 ,   "J11a_glass_FuHua_SPC"      , false};


    --Cockpit
    {"su27_tex01"			, 0	,	"J11a_tex01_FuHua"		    , false};
    {"su27_tex01"			, 3 ,	"J11a_decol_FuHua"		    , false};
}

	--Displaynames
	name 	=	"Honkai 3rd FuHua"
	name_cn	=	"崩坏三 符华"
	name_ru	=	"Xонкай импакт 3-я ФуХуа"
	
	--Countries
	--countries = {"CHN",}
	--NOTE: if you disable/remove the country line, it will be avaiable to every country in the game that has the plane
	
	--Livery by fightless Ivan
	--Edited by Wyvern (Discord: Wyvern#1312, if it doesnt work try Wyvern#0613)