\\\     This is a Readme file and can be deleted directly   \\\

To use this mod: 
    
        -   Unzip and paste the 'CoreMods' folder into your DCS root folder;

        -   This mod may conflict with your original J-11A mod, because I put \n
            most of the texture files under the original 'Textures\J-11A' folder;

        -   Please check the original tail name of texture files NOT include:  _10.dds / _10_SPC.dds    (Plane-body textures only, like J11a_tex..)


Thanks for using this mod, this is my 1st mod in DCS World;
I am still learning about the modeling in this game, you are welcome to advice or support;

All materials/picture are taken from the Internet;





\\\     此文件可直接删除不影响使用    \\\

食用方法:

        -   将 'CoreMods' 文件夹解压并放入 DCS 根目录;

        -   此模组可能会和原始的 J-11A 涂装冲突, 因为我将机体贴图放在了 'Textures\J-11A'(即初始自带涂装文件夹) 下面;
            (技术力太差, .lua没完全搞明白只好妥协)

        -   请确保上一条文件夹内的文件名末尾不包含: _10.dds / _10_SPC,dds   (仅限机体贴图)



感谢使用本mod, 这是我在DCS内第一个mod;
依旧在努力学 (摸) 习 (鱼) 改模, 欢迎提供建议或者帮助;

所有素材均来自互联网;


(真的会有人读readme吗(