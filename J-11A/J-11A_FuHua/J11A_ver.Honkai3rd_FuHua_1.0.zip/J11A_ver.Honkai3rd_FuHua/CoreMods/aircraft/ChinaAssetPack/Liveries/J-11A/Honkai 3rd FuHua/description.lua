livery = {
    {"pilot_Ka50_body", 0, "pilot_J11a", false};
    {"pilot_SU_body", 0, "pilot_cnk", false};
    {"pilot_J11a_helmet", 0, "pilot_J11a_helmet", false};
    {"pilot_J11a_patch", 0, "pilot_J11a_patch", false};
    {"j11a_glass", 0, "J11a_glass", false};
    {"j11a_glass_compos", 0, "J11a_glass", false};
    {"j11a_glass", 3, "empty", true};
    {"j11a_glass_compos", 3, "empty", true};

    {"j11a_tex01", 3, "J11a_decol", false};
    {"j11a_tex03_compos", 3, "J11a_decol", false};
    {"j11a_tex04", 3, "J11a_decol", false};
    {"j11a_tex05", 3, "J11a_decol", false};
    {"j11a_tex06", 3, "J11a_decol", false};
    {"j11a_tex06_BN52", 3, "J11a_numbers_Y", false};
    {"j11a_tex06_BN31", 3, "J11a_numbers_Y", false};
    {"j11a_tex06_BN32", 3, "J11a_numbers_Y", false};
    {"j11a_detail_compos", 3, "J11a_decol", false};	

    {"j11a_tex01", 0, "J11a_tex01_10", true};
    {"j11a_tex02_compos", 0, "J11a_tex02_10", true};
    {"j11a_tex02", 0, "J11a_tex02_10", true};
    {"j11a_tex03", 0, "J11a_tex03_10", true};
    {"j11a_tex03_compos", 0, "J11a_tex03_10", true};
    {"j11a_tex04", 0, "J11a_tex04_10", true};
    {"j11a_tex05", 0, "J11a_tex05_10", true};
    {"j11a_tex06", 0, "J11a_tex06_10", true};
    {"j11a_tex06_BN52", 0, "J11a_tex06_10", true};
    {"j11a_tex06_BN31", 0, "J11a_tex06_10", true};
    {"j11a_tex06_BN32", 0, "J11a_tex06_10", true};
    {"j11a_tex07", 0, "J11a_tex07_10", true};
    {"j11a_detail", 0, "J11a_detail", true};


    --SPC
    {"j11a_tex01", 2 ,"J11a_tex01_10_SPC",true};
    {"j11a_tex01_BN31", 2 ,"J11a_tex01_10_SPC",true};
    {"j11a_tex01_BN32", 2 ,"J11a_tex01_10_SPC",true};
    {"j11a_tex02", 2 ,"J11a_tex02_10_SPC",true};
    {"j11a_tex02_compos", 2 ,"J11a_tex02_10_SPC",true};
    {"j11a_tex03", 2 ,"J11a_tex03_10_SPC",true};
    {"j11a_tex03_compos", 2 ,"J11a_tex03_10_SPC",true};
    {"j11a_tex04", 2 ,"J11a_tex04_10_SPC",true};
    {"j11a_tex05", 2 ,"J11a_tex05_10_SPC",true};
    {"j11a_tex06", 2 ,"J11a_tex06_10_SPC",true};
    {"j11a_tex06_BN52", 2, "J11a_tex06_10_SPC", true};
    {"j11a_tex06_BN31", 2, "J11a_tex06_10_SPC", true};
    {"j11a_tex06_BN32", 2, "J11a_tex06_10_SPC", true};
    {"j11a_tex07", 2 ,"J11a_tex07_10_SPC",true};
}
name = "Honkai 3rd FuHua"
name_cn = "崩坏三 符华"
countries = {"CHN"}

--Livery by fightless Ivan