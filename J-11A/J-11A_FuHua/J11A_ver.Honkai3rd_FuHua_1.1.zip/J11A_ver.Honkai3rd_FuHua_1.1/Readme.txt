\\\     This is a Readme file and can be deleted directly   \\\

To use this mod: 
    
        -   Unzip and paste the 'CoreMods' folder into your DCS root folder;


Thanks for using this mod, this is my 1st mod in DCS World;
I am still learning about the modeling in this game, you are welcome to advice or support;

All materials/picture are taken from the Internet;





\\\     此文件可直接删除不影响使用    \\\

食用方法:

        -   将 'CoreMods' 文件夹解压并放入 DCS 根目录;


感谢使用本mod, 这是我在DCS内第一个mod;
依旧在努力学 (摸) 习 (鱼) 改模, 欢迎提供建议或者帮助;

所有素材均来自互联网;


(真的会有人读readme吗(