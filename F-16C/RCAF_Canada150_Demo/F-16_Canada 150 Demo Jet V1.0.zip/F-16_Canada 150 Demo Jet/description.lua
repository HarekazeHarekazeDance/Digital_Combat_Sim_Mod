-- livery by Flightless Ivan

-- CANADA 150 @copy right
	--Logo design by concu par Ariana Cuvin
	--Paint scheme design by/livre concu par Jin Belliveau


livery = {

	{"pilot_F16_helmet", 	0		,	"pilot_F16_helmet_a"		,	false};
	{"pilot_F16_helmet", 	13		,	"pilot_F16_helmet_mg"		,	false};

	{"pilot_F16_patch", 	0		,	"pilot_F16_patch_a"			,	false};
	{"pilot_F16_patch", 	13		,	"pilot_F16_patch_mg"		,	false};
	{"pilot_F16_patch", 	1 		,	"pilot_F16_patch_n"			,	false};

	{"pilot_F16", 			0		, 	"pilot_F16"					, 	false};




	{"F16_bl50_Main_1",		0		,	"F16_1_CANADA_150_a" ,		false};
	{"F16_bl50_Main_1",	 	13 		,	"F16_1_CANADA_150_mg", 		false};
	

	{"F16_bl50_Main_2",		0		,	"F16_2_CANADA_150_a" ,		false};
	{"F16_bl50_Main_2",	 	13 		,	"F16_2_CANADA_150_mg", 		false};
		

	{"F16_bl50_Main_3",		0		,	"F16_3_CANADA_150_a" ,		false};
	{"F16_bl50_Main_3",	 	13 		,	"F16_3_CANADA_150_mg", 		false};
		

	{"F16_bl50_wing_L",		0		,	"F16_wL_CANADA_150_a"	,	false};
	{"F16_bl50_wing_L",		13		,	"F16_wL_CANADA_150_mg"	, 	false};
		

	{"F16_bl50_wing_R",		0		,	"F16_wR_CANADA_150_a"	,	false};
	{"F16_bl50_wing_R",		13		,	"F16_wR_CANADA_150_mg"	,	false};	
	

	{"F16_bl50_Kil",		0		,	"F16_wT_CANADA_150_a" 	,	false};
	{"F16_bl50_Kil",		13		,	"F16_wT_CANADA_150_mg"	,	false};
	

	{"F16_bl50_Engine", 	0		, 	"F16_EG_CANADA_150_a"	, 	false};
	{"F16_bl50_Engine", 	13		, 	"F16_EG_CANADA_150_mg"	, 	false};






	{"F16_bl50_Wing_Pylon_1", 		0		,	"WP_1_a"	,	false};
	{"F16_bl50_Wing_Pylon_1", 		13 		,	"WP_1_mg"	,	false};



	{"F16_bl50_Wing_Pylon_2", 		0		,	"WP_2_a"	,	false};
	{"F16_bl50_Wing_Pylon_2", 		13 		,	"WP_2_mg"	,	false};



	{"LAU_129",			0		,	"WP_1and9_a"	,	false};
	{"LAU_129",			13		,	"WP_1and9_mg"	, 	false};
	



	{"Fuel_Tank_300Gal", 	0	, "FT_300_a"	, 	false};
	{"Fuel_Tank_300Gal", 	13	, "FT_300_mg"	, 	false};

	{"Tank_370", 		0		, "FT_370_a"	,	false};
	{"Tank_370", 		13		, "FT_370_mg"	,	false};

	{"MXU-648", 		0			, "TPod_a"			, 	false};
	{"MXU-648",			13			, "Tpod_mg"			, 	false};
}


name = "F-16_Canada 150 Demo Jet"


custom_args = 
{
	[1000] = 1.0, -- change of type of board number (0.0 -default USA, 0.1- )
	[1001] = 1.0, -- vis refuel board number 
	[1002] = 1.0, -- change of type intake board number 
	[1003] = 1.0, -- vis nouse board number 
}