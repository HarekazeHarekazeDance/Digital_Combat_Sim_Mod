-- livery by Flightless Ivan
livery = {
	-------------------------------------PILOT-----------------------------------------
	-- Pilot
		--头盔
		{"pilot_F16_helmet", 	0		,	"pilot_F16_helmet_a"		,	false};
		{"pilot_F16_helmet", 	13		,	"pilot_F16_helmet_mg"		,	false};
		--[[
			--遮光镜(doesn't work?)
			{"pilot_F16_visor",		0		,	"pilot_F16_visor_a"			,	false};
			{"pilot_F16_visor",		13		,	"pilot_F16_visor_mg"		,	false};
		]]


		--徽章
		{"pilot_F16_patch", 	0		,	"pilot_F16_patch_a"			,	false};
		{"pilot_F16_patch", 	13		,	"pilot_F16_patch_mg"		,	false};
		{"pilot_F16_patch", 	1 		,	"pilot_F16_patch_n"			,	false};
		--Body
		{"pilot_F16", 			0		, 	"pilot_F16_a"					, 	false};
	
	
	----------------------------------AIRCRAFT BODY----------------------------------
	-- F16_bl50_Main_1
		--前, 后机背
		{"F16_bl50_Main_1",		0		,	"F16_1_CANADA_150_a" ,		false};
		{"F16_bl50_Main_1",	 	13 		,	"F16_1_CANADA_150_mg", 		false};
		
	-- F16_bl50_Main_2
		--前, 后机腹 & 正侧 & 扰流板 & 雷达罩
		{"F16_bl50_Main_2",		0		,	"F16_2_CANADA_150_a" ,		false};
		{"F16_bl50_Main_2",	 	13 		,	"F16_2_CANADA_150_mg", 		false};
			
	-- F16_bl50_Main_3
		--中机腹(进气道)
		{"F16_bl50_Main_3",		0		,	"F16_3_CANADA_150_a" ,		false};
		{"F16_bl50_Main_3",	 	13 		,	"F16_3_CANADA_150_mg", 		false};
			
	-- F16_bl50_wing_L
		--左翼
		{"F16_bl50_wing_L",		0		,	"F16_wL_CANADA_150_a"	,	false};
		{"F16_bl50_wing_L",		13		,	"F16_wL_CANADA_150_mg"	, 	false};
			
	-- F16_bl50_wing_R
		--右翼
		{"F16_bl50_wing_R",		0		,	"F16_wR_CANADA_150_a"	,	false};
		{"F16_bl50_wing_R",		13		,	"F16_wR_CANADA_150_mg"	,	false};	
		
	-- F16_bl50_Kil
		--垂尾
		{"F16_bl50_Kil",		0		,	"F16_wT_CANADA_150_a" 	,	false};
		{"F16_bl50_Kil",		13		,	"F16_wT_CANADA_150_mg"	,	false};
		
	-- F16_bl50_Engine
		--尾喷口
		{"F16_bl50_Engine", 	0		, 	"F16_EG_CANADA_150_a"	, 	false};
		{"F16_bl50_Engine", 	13		, 	"F16_EG_CANADA_150_mg"	, 	false};
	
	-- F16_bl50_Glass
		--玻璃
		{"F16_bl50_GLASS"		,    	DIFFUSE         ,   "F16_bl50_Glass_a"		, 	false};
		{"F16_bl50_GLASS"		,    	14        		,   "F16_bl50_Glass_a"		, 	false};
		{"F16bl50__GLASS_CLear"	,    	DIFFUSE         ,   "F16_bl50_Glass_a"		, 	false};
		{"F16bl50__GLASS_CLear"	,    	14        		,   "F16_bl50_Glass_a"		, 	false};
		{"F16_bl50_GLASS"		, 		13		  		,   "F16_bl50_Glass_mg"		, 	false};
		{"F16_bl50_GLASS_CLear"	, 		13		  		,   "F16_bl50_Glass_mg"		, 	false};
		--驾驶舱玻璃
		{"f16c-cpt_glass_instr_anim2"	,		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_hud"			,		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_instr_anim3"	,		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_canopy_white"	,		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_canopy_clw"	,		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_sum"			,		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_instr_anim3_cl",		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_instr_anim2_cl",		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_hud_cl"		,		14		,	"f16c_glass_canopy_dif"			,	 false};
		{"f16c-cpt_glass_canopy_gold"	,		14		,	"f16c_glass_canopy_gold_dif"	,	 false};
		{"f16c-cpt_glass_canopy_clgd"	,		14		,	"f16c_glass_canopy_gold_dif"	,	 false};


	---	发射架
	-- F16_bl50_Wing_Pylon_1
		{"F16_bl50_Wing_Pylon_1", 		0		,	"WP_1_a"	,	false};
		{"F16_bl50_Wing_Pylon_1", 		13 		,	"WP_1_mg"	,	false};
	
	-- F16_bl50_Wing_Pylon_2
		{"F16_bl50_Wing_Pylon_2", 		0		,	"WP_2_a"	,	false};
		{"F16_bl50_Wing_Pylon_2", 		13 		,	"WP_2_mg"	,	false};
	
	
	-- Pylon 1 & 9
		{"LAU_129",			0		,	"WP_1and9_a"	,	false};
		{"LAU_129",			13		,	"WP_1and9_mg"	, 	false};
		
	
	
	
	----------------------------------LOAD---------------------------------------
	---	副油箱
	-- F16_bl50_Fuel_Tank_300Gal
		{"Fuel_Tank_300Gal", 	0	, "FT_300_a"	, 	false};
		{"Fuel_Tank_300Gal", 	13	, "FT_300_mg"	, 	false};
	
	-- F16_bl50_Fuel_Tank_370Gal
		{"F_16_Tank_370", 		0		, "FT_370_a"	,	false};
		{"F_16_Tank_370", 		13		, "FT_370_mg"	,	false};
	
	 --Travel Pod
		{"MXU-648", 		0			, "TPod_a"			, 	false};
		{"MXU-648",			13			, "Tpod_mg"			, 	false};
	} -- end of livery
	
	-- Livery name in game
	name = "F-16_Canada 150 Demo Jet"
	
	-- Number
	custom_args = {
		[1000] = 1.0, -- change of type of board number (0.0 -default USA, 0.1- )
		[1001] = 1.0, -- vis refuel board number 
		[1002] = 1.0, -- change of type intake board number 
		[1003] = 1.0, -- vis nouse board number 
	}


-------------------------------------------------------------------------------------
---FILE NAME STRUCTURE
-- a = diffuse map
-- mg = roughness metallic map
-- n = normal map



-- Technical Support: Wyvern Ace

---RENDER TYPE/CODE
--DIFFUSE = 0
--NORMAL_MAP = 1
--SPECULAR = 2
--DECAL = 3
--DIRT = 4
--DAMAGE = 5
--PUDDLES = 6
--SNOW = 7
--SELF_ILLUMINATION = 8
--AMBIENT_OCCLUSION = 9
--ROUGHNESS_METALLIC = 13