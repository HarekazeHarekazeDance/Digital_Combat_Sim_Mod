\\\     This is a Readme file and can be deleted directly   \\\

To use this mod: 
        -   Unzip and paste the folder into:

                C:\User\'Your user name'\SavedGame\DCS\Liveries\F-16C_50  ; 
                (If Liveries\F-16C_50 folder is not exist, just create it.  This path would NOT break the Integrity Check)


All materials/picture are taken from the Internet;

CANADA 150 @copy right
	--Logo design by concu par Ariana Cuvin
	--Paint scheme design by/livre concu par Jin Belliveau





\\\     此文件可直接删除不影响使用    \\\

食用方法:
        -   将文件夹解压并放入:       

                C:\用户\'你的用户名'\保存的游戏\DCS\Liveries\F-16C_50   ;
                (如果 Liveries\F-16C_50 不存在的话直接新建一个, 这个路径不会破坏完整性检查)


所有素材均来自互联网;

CANADA 150 @copy right
	--Logo design by concu par Ariana Cuvin
	--Paint scheme design by/livre concu par Jin Belliveau

